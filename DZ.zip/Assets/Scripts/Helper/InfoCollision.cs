﻿using UnityEngine;

namespace Geekbrains
{
    public struct InfoCollision
    {
        private readonly Vector3 _dir;
        private readonly float _damage;
        private readonly float _scale;
        public Vector3 Dir => _dir;
        public float Damage => _damage;

        public InfoCollision(float damage = default, Vector3 dir = default, float scale = default)
        {
            _damage = damage;
            _dir = dir;
            _scale = scale;
        }

    }
}
