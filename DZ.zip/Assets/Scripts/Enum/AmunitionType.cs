﻿namespace Geekbrains
{
    public enum AmmunitionType
    {
        Rpg = 2,
        PistolBullet = 4,
        GunBullet = 8,
        Rocket = 16
    }
}
