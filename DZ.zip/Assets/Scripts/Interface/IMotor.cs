﻿namespace Geekbrains
{
	public interface IMotor
	{
		void Move();
	}
}