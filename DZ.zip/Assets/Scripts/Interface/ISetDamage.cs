﻿namespace Geekbrains
{
    public interface ISetDamage
    {
        void SetDamage(InfoCollision info);
    }
}
