﻿namespace Geekbrains
{
    public interface ISetScale
    {
        void SetScale(InfoCollision info);
    }
}