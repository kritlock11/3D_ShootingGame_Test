﻿using System.Collections;
using UnityEngine;

namespace Geekbrains
{
    public class EnemyController : BaseController, IInitialization, ISetDamage, ISelectObj, ISetScale//, IOnUpdate
    {
        private EnemyModel _enemyModel;

        public void Init()
        {
            _enemyModel = Object.FindObjectOfType<EnemyModel>();
            //UiInterface.EnemyUi_Slider.SetActive(true);
            //UiInterface.EnemyUi_Text.SetActive(true);

            //Switch(false);
        }
        //public void Switch(bool value)
        //{
        //    UiInterface.EnemyUi_Slider.gameObject.SetActive(value);
        //}

        //public override void On()
        //{
        //    if (IsActive) return;
        //    if (_enemyModel == null) return;
        //    if (UiInterface.EnemyUi_Slider == null) return;
        //    base.On();
        //    Switch(true);
        //}

        //public override void Off()
        //{
        //    if (!IsActive) return;
        //    base.Off();
        //    Switch(false);
        //}
        public void SetDamage(InfoCollision info)
        {
            if (_enemyModel._isDead) return;
            if (_enemyModel.Hp > 0)
            {
                _enemyModel.Hp -= info.Damage;
            }

            if (_enemyModel.Hp <= 0)
            {
                Object.Destroy(_enemyModel.gameObject);
                _enemyModel._isDead = true;
            }
        }
        public string GetMessage()
        {
            return _enemyModel.gameObject.name;
        }
        public void SetScale(InfoCollision info)
        {
            _enemyModel.transform.localScale = new Vector3(5, 5, 5);
        }
    }
}
