﻿using System;
using UnityEngine;

namespace Geekbrains
{
    public class EnemyModel : BaseObjectScene, ISelectObj, ISetDamage, ISetScale, ISetNoDefense
    {
        public event Action OnPointChange;

        [SerializeField] private float _hp = 100;
        [SerializeField] private float _maxHp = 100;
        [SerializeField] private float _defense = 5;

        public bool _isDead = false;

        //todo дописать поглащение урона
        public float Hp { get => _hp; set => _hp = value; }
        public float Defense { get => _defense; set => _defense = value; }
        public float MaxHp { get => _maxHp; set => _maxHp = value; }

        public void SetDamage(InfoCollision info)
        {
            if (_isDead) return;
            if (_defense >0)
            {
                _defense -= 1;
            }
            else if (_defense<=0 && _hp > 0)
            {
                OnPointChange?.Invoke();
                _hp -= info.Damage;
            }

            if (_hp <= 0)
            {
                Destroy(gameObject);
                _isDead = true;
            }
        }
        public string GetMessage()
        {
            return gameObject.name;
        }
        public void SetScale(InfoCollision info)
        {
            transform.localScale = new Vector3(5, 5, 5);
        }
        public void ISetNoDefense()
        {
            if (_isDead) return;
            if (_defense > 0)
            {
                _defense = 0;
            }
        }
    }
}

