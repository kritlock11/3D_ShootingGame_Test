﻿namespace Geekbrains
{
    public struct Clip
    {
        public int CountAmmunition;
    }
}
