﻿namespace Geekbrains
{
    public enum StateBot
    {
        Non,
        Patrol,
        Inspection,
        Detected,
        Died
    }
}
