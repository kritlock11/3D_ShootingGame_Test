﻿using System.Linq;

namespace Geekbrains
{
    public static class Crypto
    {
        public static string CryptoXOR(string text, int key = 42) => new string(text.Select(o => (char)(o ^ key)).ToArray());
    }
}