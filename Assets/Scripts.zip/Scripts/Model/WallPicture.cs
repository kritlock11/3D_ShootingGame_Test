﻿namespace Geekbrains
{
    public class WallPicture : BaseObjectScene, IGrabObj
    {
        public string GetText()
        {
            return Name;
        }
    }
}