﻿using System;
using UnityEngine;
namespace Geekbrains
{
    public class RocketModel : BaseAmmunition
    {
        public AmmunitionType Type = AmmunitionType.Rocket;

        private void OnEnable()
        {
            transform.GetComponent<Rigidbody>().WakeUp();
            DestroyAmmunition(_timeToDestruct);
        }
        private void OnDisable()
        {
            transform.GetComponent<Rigidbody>().Sleep();
            CancelInvoke();
        }
        private void OnCollisionEnter(Collision collision)
        {
            Explode();


            //var tempObj = collision.gameObject.GetComponent<ISetScale>();
            //if (tempObj != null)
            //{
            //    if (collision.gameObject.GetComponent<PistolBulletModel>())
            //    {
            //        return;
            //    }
            //    tempObj.SetScale(new InfoCollision());
            //}
            //gameObject.SetActive(false);
        }

        private void Explode()
        {
            var boomPos = transform.position;

            Collider[] colliders = Physics.OverlapSphere(boomPos, 10);
            foreach (var item in colliders)
            {
                Rigidbody rb = item.GetComponent<Rigidbody>();
                if (rb!=null)
                {
                    rb.AddExplosionForce(3000, boomPos, 10);
                }
            }





            gameObject.SetActive(false);
        }
    }
}

