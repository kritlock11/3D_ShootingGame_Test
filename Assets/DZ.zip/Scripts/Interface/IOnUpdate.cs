﻿namespace Geekbrains
{
	public interface IOnUpdate
	{
		void OnUpdate();
	}
}