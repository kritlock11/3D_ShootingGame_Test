﻿using UnityEngine;

namespace Geekbrains
{
    public interface IGrabObj
    {
        string GetText();
    }
}
