﻿using System.Collections;

namespace Geekbrains
{
    interface ICasteble
    {
        IEnumerator Cast();
    }
}

