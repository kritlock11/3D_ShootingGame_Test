﻿namespace Geekbrains
{
    public interface ISetNoDefense
    {
        void ISetNoDefense();
    }
}
