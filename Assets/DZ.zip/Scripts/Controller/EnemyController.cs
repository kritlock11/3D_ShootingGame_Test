﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace Geekbrains
{
    public class EnemyController : BaseController, IInitialization, IOnUpdate
    {
        public int CountBot = 10;
        Main Main;
        public HashSet<EnemyModel> GetBotList { get; } = new HashSet<EnemyModel>();

        public void Init()
        {
            Main = ServiceLocator.GetService<Main>();
            for (var index = 0; index < CountBot; index++)
            {
                var tempBot = Object.Instantiate(Main.EnemyModelPrefab,
                    Patrol.GenericPoint(Main.Player),
                    Quaternion.identity);

                tempBot.Agent.avoidancePriority = index;
                tempBot.Target = Main.Player; //todo разных противников
                AddBotToList(tempBot);
                tempBot.OnDieChange += RemoveBotToList;
            }
        }
        private void AddBotToList(EnemyModel bot)
        {
            if (!GetBotList.Contains(bot))
            {
                GetBotList.Add(bot);
            }
        }

        private void RemoveBotToList(EnemyModel bot)
        {
            if (GetBotList.Contains(bot))
            {
                bot.OnDieChange -= RemoveBotToList;
                GetBotList.Remove(bot);
            }
        }

        public void OnUpdate()
        {
            if (!IsActive)
            {
                return;
            } 
            for (var i = 0; i < GetBotList.Count; i++)
            {
                var bot = GetBotList.ElementAt(i);
                bot.Tick();
            }
        }
        
    }
}
