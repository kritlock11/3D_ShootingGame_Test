﻿namespace Geekbrains
{
    public enum AmmunitionType
    {
        Knife = 2,
        PistolBullet = 4,
        GunBullet = 8,
        Rocket = 16
    }
}
