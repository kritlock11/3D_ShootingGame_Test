﻿namespace Geekbrains
{
    public interface ISetLegKick
    {
        void SetLegKick();
    }
}
